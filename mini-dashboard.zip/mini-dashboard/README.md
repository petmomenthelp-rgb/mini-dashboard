# Mini Dashboard (GitHub Learning Project)

Ein super kleines Projekt, um GitHub-Basics zu lernen:

- Repo / Commit / Push
- Branches & Pull Requests
- GitHub Actions (CI)

## Lokal öffnen
Einfach `index.html` im Browser öffnen.

## Tests
```bash
npm test
```
