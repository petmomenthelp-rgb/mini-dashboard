// Mini-Tests, damit GitHub Actions etwas "echtes" prüfen kann.
const assert = require("assert");

function minutesToHours(min) {
  return Math.round((min / 60) * 10) / 10;
}

function sumMinutes(obj) {
  return Object.values(obj).reduce((a, b) => a + b, 0);
}

// Tests
assert.strictEqual(minutesToHours(60), 1.0);
assert.strictEqual(minutesToHours(30), 0.5);
assert.strictEqual(sumMinutes({ a: 10, b: 20, c: 5 }), 35);

console.log("✅ Tests passed");
